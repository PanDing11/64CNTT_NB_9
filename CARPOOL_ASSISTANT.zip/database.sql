CREATE DATABASE hots;
USE hots;

CREATE TABLE KhachHang(
	MSKH int NOT NULL auto_increment PRIMARY KEY,
    HoTenKH VARCHAR(50) ,
    MatKhau VARCHAR(10) DEFAULT '1',
	SoDienThoai VARCHAR(10),
    EMail VARCHAR(50) UNIQUE
);


CREATE TABLE NhaXe(
	MSNX int NOT NULL auto_increment PRIMARY KEY,
    TenNX VARCHAR(50) ,
    EMail VARCHAR(50) UNIQUE,
	SoDienThoai VARCHAR(10)
);


CREATE TABLE NhanVien(
	MSNV int NOT NULL auto_increment PRIMARY KEY,
    HoTenNV VARCHAR(50) ,
    SoDienThoai VARCHAR(10) ,
	ChucVu VARCHAR(50) ,
	MSNX int NOT NULL,
	MatKhau VARCHAR(10) DEFAULT '1',
    EMail VARCHAR(50) UNIQUE,
	FOREIGN KEY (MSNX) REFERENCES NhaXe(MSNX)
);



CREATE TABLE LoaiXe(
	MaLoai int NOT NULL auto_increment PRIMARY KEY,
	SoTang int NOT NULL,
	SoGhe int NOT NULL,
    TenLoai VARCHAR(50) NOT NULL
);


CREATE TABLE Xe(
	MaXe int NOT NULL auto_increment PRIMARY KEY,
	MaLoai int NOT NULL,
	MSNX int NOT NULL,
	BienSo VARCHAR(50) NOT NULL,
	FOREIGN KEY (MSNX) REFERENCES NhaXe(MSNX),
	FOREIGN KEY (MaLoai) REFERENCES LoaiXe(MaLoai)
);

CREATE TABLE TuyenDuong(
	MaTD int NOT NULL auto_increment PRIMARY KEY,
	DiemBatDau VARCHAR(50) NOT NULL,
	DiemKetThuc VARCHAR(50) NOT NULL
);

CREATE TABLE ChuyenXe(
	MaCX int NOT NULL auto_increment PRIMARY KEY,
	MaTD int NOT NULL,
	MaXe int NOT NULL,
	GioKhoiHanh TIME,
    GioCapBen TIME,
	SoGheTrong int NOT NULL,
	MSNV1 int NOT NULL, -- Phu Xe
	MSNV2 int NOT NULL, -- Tai Xe
	FOREIGN KEY (MSNV1) REFERENCES NhanVien(MSNV),
	FOREIGN KEY (MSNV2) REFERENCES NhanVien(MSNV)
);

CREATE TABLE VeXe(
	MaVX int NOT NULL auto_increment PRIMARY KEY,
	MaCX int NOT NULL,
	GiaVe int NOT NULL,
	SoGhe int NOT NULL,
	NgayXeChay DATE NOT NULL,
	FOREIGN KEY (MaCX) REFERENCES ChuyenXe(MaCX)
);

SELECT DATE_FORMAT(NgayXeChay, '%d/%m/%Y') FROM VeXe;



CREATE TABLE DatVeXe(
	MaDV int NOT NULL auto_increment PRIMARY KEY,
	MaVX int NOT NULL, 
	MSKH int NOT NULL,
	NgayDV DATE DEFAULT CURRENT_TIMESTAMP,
	TrangThai VARCHAR(50) DEFAULT 'Đã Đặt', -- 0 Da Dat 1 Da Huy 2 Hoan Thanh
	FOREIGN KEY (MaVX) REFERENCES VeXe(MaVX),
	FOREIGN KEY (MSKH) REFERENCES KhachHang(MSKH)
);

SELECT DATE_FORMAT(NgayDV, '%d/%m/%Y') FROM DatVeXe;


CREATE TABLE DanhGia(
	MaDG int NOT NULL auto_increment PRIMARY KEY,
	MaVX int NOT NULL, 
	MSKH int NOT NULL,
	SoDiem int NOT NULL,
	MoTa VARCHAR(500) DEFAULT '',
	FOREIGN KEY (MaVX) REFERENCES VeXe(MaVX),
	FOREIGN KEY (MSKH) REFERENCES KhachHang(MSKH)
);

INSERT INTO KhachHang(HoTenKH, EMail, MatKhau, SoDienThoai) VALUES ('admin', 'admin@gmail.com', 'admin', '03421212');



INSERT INTO NhaXe(TenNX, EMail, SoDienThoai) VALUES('Đức Toàn', 'ductoan@gmail.com', '0342222');
INSERT INTO NhaXe(TenNX, EMail, SoDienThoai) VALUES('Chiến Thắng', 'chienthang@gmail.com', '0342221');
INSERT INTO NhaXe(TenNX, EMail, SoDienThoai) VALUES('Admin', 'admin@gmail.com', '000000');


INSERT INTO NhanVien(HoTenNV, ChucVu, SoDienThoai, MSNX, EMail) VALUES('Tống Giang', 'Tài Xế', '11111112', '1', 'tg@gmail.com');
INSERT INTO NhanVien(HoTenNV, ChucVu, SoDienThoai, MSNX, EMail) VALUES('Ngô Dụng', 'Phụ Xế', '11111114', '1', 'nd@gmail.com');
INSERT INTO NhanVien(HoTenNV, ChucVu, SoDienThoai, MSNX, EMail) VALUES('Lư Tuấn Nghĩa', 'Tài Xế', '11111113', '1', 'ltn@gmail.com');
INSERT INTO NhanVien(HoTenNV, ChucVu, SoDienThoai, MSNX, EMail) VALUES('Công Tôn Thắng', 'Phụ Xế', '11111115', '1', 'ctt@gmail.com');

INSERT INTO NhanVien(HoTenNV, ChucVu, SoDienThoai, MSNX, EMail) VALUES('Quan Thắng', 'Tài Xế', '11111116', '2', 'qt@gmail.com');
INSERT INTO NhanVien(HoTenNV, ChucVu, SoDienThoai, MSNX, EMail) VALUES('Tần Minh', 'Phụ Xế', '11111118', '2', 'tm@gmail.com');
INSERT INTO NhanVien(HoTenNV, ChucVu, SoDienThoai, MSNX, EMail) VALUES('Lâm Xung', 'Tài Xế', '11111117', '2', 'lx@gmail.com');
INSERT INTO NhanVien(HoTenNV, ChucVu, SoDienThoai, MSNX, EMail) VALUES('Hô Duyên Chước', 'Phụ Xế', '11111119', '2', 'hdc@gmail.com');

INSERT INTO NhanVien(HoTenNV, ChucVu, SoDienThoai, MSNX, EMail) VALUES('Admin', 'Admin', '000000000', '3', 'admin@gmail.com');


INSERT INTO LoaiXe(SoTang, SoGhe, TenLoai) VALUES ('1', '16', '16 Chỗ Ghế Ngồi');
INSERT INTO LoaiXe(SoTang, SoGhe, TenLoai) VALUES ('2', '40', '40 Chỗ Giường Nằm');
INSERT INTO LoaiXe(SoTang, SoGhe, TenLoai) VALUES ('1', '20', '20 Chỗ Ghế NGồi');

INSERT INTO Xe(MaLoai, MSNX, BienSo) VALUES ('1', '1', 'AF110');
INSERT INTO Xe(MaLoai, MSNX, BienSo) VALUES ('2', '1', 'AF112');
INSERT INTO Xe(MaLoai, MSNX, BienSo) VALUES ('2', '2', 'GF112');
INSERT INTO Xe(MaLoai, MSNX, BienSo) VALUES ('3', '2', 'DF113');

INSERT INTO TuyenDuong(DiemBatDau, DiemKetThuc) VALUES ('Hà Nội', 'Hạ Long');
INSERT INTO TuyenDuong(DiemBatDau, DiemKetThuc) VALUES ('Hạ Long', 'Hà Nội');
INSERT INTO TuyenDuong(DiemBatDau, DiemKetThuc) VALUES ('Hà Nội', 'Ninh Bình');
INSERT INTO TuyenDuong(DiemBatDau, DiemKetThuc) VALUES ('Ninh Bình', 'Hà Nội');

INSERT INTO ChuyenXe(MaTD, MaXe, GioKhoiHanh, GioCapBen, SoGheTrong, MSNV1, MSNV2) VALUES ('1', '1', '07:00:00', '07:05:00', '16', '1', '2');
INSERT INTO ChuyenXe(MaTD, MaXe, GioKhoiHanh, GioCapBen, SoGheTrong, MSNV1, MSNV2) VALUES ('2', '1', '08:00:00', '08:05:00', '16', '1', '2');
INSERT INTO ChuyenXe(MaTD, MaXe, GioKhoiHanh, GioCapBen, SoGheTrong, MSNV1, MSNV2) VALUES ('3', '2', '09:00:00', '09:05:00', '40', '3', '4');
INSERT INTO ChuyenXe(MaTD, MaXe, GioKhoiHanh, GioCapBen, SoGheTrong, MSNV1, MSNV2) VALUES ('4', '2', '10:00:00', '10:05:00', '40', '3', '4');

INSERT INTO ChuyenXe(MaTD, MaXe, GioKhoiHanh, GioCapBen, SoGheTrong, MSNV1, MSNV2) VALUES ('1', '3', '01:00:00', '01:05:00', '40', '5', '6');
INSERT INTO ChuyenXe(MaTD, MaXe, GioKhoiHanh, GioCapBen, SoGheTrong, MSNV1, MSNV2) VALUES ('2', '3', '02:00:00', '02:05:00', '40', '5', '6');
INSERT INTO ChuyenXe(MaTD, MaXe, GioKhoiHanh, GioCapBen, SoGheTrong, MSNV1, MSNV2) VALUES ('3', '4', '03:00:00', '03:05:00', '20', '7', '8');
INSERT INTO ChuyenXe(MaTD, MaXe, GioKhoiHanh, GioCapBen, SoGheTrong, MSNV1, MSNV2) VALUES ('4', '4', '04:00:00', '04:05:00', '20', '7', '8');

INSERT INTO ChuyenXe(MaTD, MaXe, GioKhoiHanh, GioCapBen, SoGheTrong, MSNV1, MSNV2) VALUES ('1', '1', '11:00:00', '11:05:00', '16', '1', '2');
INSERT INTO ChuyenXe(MaTD, MaXe, GioKhoiHanh, GioCapBen, SoGheTrong, MSNV1, MSNV2) VALUES ('2', '1', '12:00:00', '12:05:00', '16', '1', '2');
INSERT INTO ChuyenXe(MaTD, MaXe, GioKhoiHanh, GioCapBen, SoGheTrong, MSNV1, MSNV2) VALUES ('3', '2', '13:00:00', '13:05:00', '40', '3', '4');
INSERT INTO ChuyenXe(MaTD, MaXe, GioKhoiHanh, GioCapBen, SoGheTrong, MSNV1, MSNV2) VALUES ('4', '2', '14:00:00', '14:05:00', '40', '3', '4');

INSERT INTO ChuyenXe(MaTD, MaXe, GioKhoiHanh, GioCapBen, SoGheTrong, MSNV1, MSNV2) VALUES ('1', '3', '15:00:00', '15:05:00', '40', '5', '6');
INSERT INTO ChuyenXe(MaTD, MaXe, GioKhoiHanh, GioCapBen, SoGheTrong, MSNV1, MSNV2) VALUES ('2', '3', '16:00:00', '16:05:00', '40', '5', '6');
INSERT INTO ChuyenXe(MaTD, MaXe, GioKhoiHanh, GioCapBen, SoGheTrong, MSNV1, MSNV2) VALUES ('3', '4', '17:00:00', '17:05:00', '20', '7', '8');
INSERT INTO ChuyenXe(MaTD, MaXe, GioKhoiHanh, GioCapBen, SoGheTrong, MSNV1, MSNV2) VALUES ('4', '4', '18:00:00', '18:05:00', '20', '7', '8');

INSERT INTO ChuyenXe(MaTD, MaXe, GioKhoiHanh, GioCapBen, SoGheTrong, MSNV1, MSNV2) VALUES ('1', '1', '19:00:00', '19:05:00', '16', '1', '2');
INSERT INTO ChuyenXe(MaTD, MaXe, GioKhoiHanh, GioCapBen, SoGheTrong, MSNV1, MSNV2) VALUES ('2', '1', '20:00:00', '20:05:00', '16', '1', '2');
INSERT INTO ChuyenXe(MaTD, MaXe, GioKhoiHanh, GioCapBen, SoGheTrong, MSNV1, MSNV2) VALUES ('3', '2', '21:00:00', '21:05:00', '40', '3', '4');
INSERT INTO ChuyenXe(MaTD, MaXe, GioKhoiHanh, GioCapBen, SoGheTrong, MSNV1, MSNV2) VALUES ('4', '2', '22:00:00', '22:05:00', '40', '3', '4');



INSERT INTO VeXe(MaCX, GiaVe, SoGhe, NgayXeChay) VALUES('1', '500', '12', STR_TO_DATE('30/12/2023', '%d/%m/%Y'));
INSERT INTO DatVeXe(MaVX, MSKH) VALUE('1', '1');

INSERT INTO DanhGia(MaVX, MSKH, SoDiem, MoTa) VALUES ('1', '1', '7', 'Good');
INSERT INTO DanhGia(MaVX, MSKH, SoDiem, MoTa) VALUES ('1', '1', '9', 'Good ee');

INSERT INTO KhachHang(HoTenKH, EMail, MatKhau, SoDienThoai) VALUES ('Trương Phi', 'tp@gmail.com', '1', '03421212');
INSERT INTO KhachHang(HoTenKH, EMail, MatKhau, SoDienThoai) VALUES ('Tào Tháo', 'tt@gmail.com', '1', '036213232');
INSERT INTO KhachHang(HoTenKH, EMail, MatKhau, SoDienThoai) VALUES ('Mã Siêu', 'ms@gmail.com', '1', '0331213245');
INSERT INTO KhachHang(HoTenKH, EMail, MatKhau, SoDienThoai) VALUES ('Bàng Thống', 'bt@gmail.com', '1', '037212132');

INSERT INTO VeXe(MaCX, GiaVe, SoGhe, NgayXeChay) VALUES('1', '500', '7', STR_TO_DATE('1/1/2024', '%d/%m/%Y'));
INSERT INTO DatVeXe(MaVX, MSKH, TrangThai) VALUE('2', '2', 'Hoàn Thành');
INSERT INTO VeXe(MaCX, GiaVe, SoGhe, NgayXeChay) VALUES('1', '500', '9', STR_TO_DATE('1/1/2024', '%d/%m/%Y'));
INSERT INTO DatVeXe(MaVX, MSKH) VALUE('3', '3');
INSERT INTO VeXe(MaCX, GiaVe, SoGhe, NgayXeChay) VALUES('1', '500', '3', STR_TO_DATE('1/1/2024', '%d/%m/%Y'));
INSERT INTO DatVeXe(MaVX, MSKH) VALUE('4', '4');
INSERT INTO VeXe(MaCX, GiaVe, SoGhe, NgayXeChay) VALUES('1', '500', '14', STR_TO_DATE('1/1/2024', '%d/%m/%Y'));
INSERT INTO DatVeXe(MaVX, MSKH) VALUE('5', '5');

INSERT INTO VeXe(MaCX, GiaVe, SoGhe, NgayXeChay) VALUES('1', '500', '7', STR_TO_DATE('1/2/2024', '%d/%m/%Y'));
INSERT INTO DatVeXe(MaVX, MSKH) VALUE('6', '2');
INSERT INTO VeXe(MaCX, GiaVe, SoGhe, NgayXeChay) VALUES('1', '500', '9', STR_TO_DATE('1/2/2024', '%d/%m/%Y'));
INSERT INTO DatVeXe(MaVX, MSKH, TrangThai) VALUE('7', '3', 'Hoàn Thành');
INSERT INTO VeXe(MaCX, GiaVe, SoGhe, NgayXeChay) VALUES('1', '500', '3', STR_TO_DATE('1/2/2024', '%d/%m/%Y'));
INSERT INTO DatVeXe(MaVX, MSKH, TrangThai) VALUE('8', '4', 'Hoàn Thành');
INSERT INTO VeXe(MaCX, GiaVe, SoGhe, NgayXeChay) VALUES('1', '500', '14', STR_TO_DATE('1/2/2024', '%d/%m/%Y'));
INSERT INTO DatVeXe(MaVX, MSKH) VALUE('9', '5');




-- DROP DATABASE IF EXISTS hots;

/*
SELECT E.TenNX, CONCAT(CONCAT(CONCAT(D.TenLoai, ' '), D.SoTang), ' Tầng'), 
B.DiemBatDau, B.DiemKetThuc, A.GioKhoiHanh, A.GioCapBen, C.BienSo, A.SoGheTrong, E.SoDienThoai,
COALESCE(ROUND((SELECT AVG(F.SoDiem) FROM DanhGia F WHERE A.MaCX = F.MaCX), 2), 'Chưa có') AS DiemTrungBinh,
COALESCE((SELECT COUNT(*) FROM DanhGia F WHERE A.MaCX = F.MaCX), 'Chưa có') AS SoLuotDanhGia
FROM ChuyenXe A, TuyenDuong B, Xe C, LoaiXe D, NhaXe E
WHERE A.MaTD = B.MaTD
AND	A.MaXe = C.MaXe
AND C.MaLoai = D.MaLoai
AND C.MSNX = E.MSNX
*/

/*
SELECT CONVERT(E.TenNX USING utf8) COLLATE utf8_general_ci, CONCAT(CONCAT(CONCAT(D.TenLoai, ' '), D.SoTang), ' Tầng'), 
B.DiemBatDau, B.DiemKetThuc, A.GioKhoiHanh, A.GioCapBen, C.BienSo, A.SoGheTrong, E.SoDienThoai,
COALESCE(ROUND((SELECT AVG(F.SoDiem) FROM DanhGia F WHERE A.MaCX = F.MaCX), 2), 'Chưa có') AS DiemTrungBinh,
COALESCE((SELECT COUNT(*) FROM DanhGia F WHERE A.MaCX = F.MaCX), 'Chưa có') AS SoLuotDanhGia
FROM ChuyenXe A, TuyenDuong B, Xe C, LoaiXe D, NhaXe E
WHERE A.MaTD = B.MaTD
AND	A.MaXe = C.MaXe
AND C.MaLoai = D.MaLoai
AND C.MSNX = E.MSNX
*/