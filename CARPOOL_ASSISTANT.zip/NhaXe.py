import os.path
from tkinter import *
from tkinter import ttk
from tkinter import messagebox
from pathlib import Path
import mysql.connector
from ttkbootstrap import DateEntry, Combobox
from ttkbootstrap import Scale as BScale
from ttkbootstrap.tableview import Tableview
from ttkbootstrap.constants import *
from ttkbootstrap import Button as BButton
from ttkbootstrap import Label as BLabel
from ttkbootstrap import Spinbox as BSpinbox
from ttkbootstrap import Frame as BFrame
from ttkbootstrap import Notebook as BNotebook
from ttkbootstrap import Entry as BEntry
from ttkbootstrap import Menubutton as BMenubutton
from ttkbootstrap import Menu as BMenu
import random
from datetime import datetime, date


# pip install mysql-connector-python
# python -m pip install ttkbootstrap


OUTPUT_PATH = Path(__file__).parent
PATH_DIR = 'D://Project//DatXe//assets//'
ASSETS_PATH = ['dialog', 'login', 'register', 'find', 'info', 'loginc', 'emp']
ASSETS_PATH = [OUTPUT_PATH / Path(os.path.join(PATH_DIR, e)) for e in ASSETS_PATH]
host = 'localhost'
user = 'root'
password = ''
database = 'hots'
port = 3306
CONNECTION = None
window = Tk()
USER_ID = None
EMP_ID = None
QUERY = ''


# Kết nối với MySQL
def connect_mysql():
    global CONNECTION
    try:
        CONNECTION = mysql.connector.connect(host=host, user=user, password=password, database=database, port=port)
        if CONNECTION.is_connected():
            return True
    except mysql.connector.Error as err:
        show_dialog(err)
        return False

# Thực hiện truy vấn (query)
def execute_querry(query: str):
    global CONNECTION
    if connect_mysql():
        try:
            cursor = CONNECTION.cursor()
            # Thực hiện truy vấn
            cursor.execute(query)
            # Lấy kết quả
            rows = cursor.fetchall()
            if 'insert into' in query.lower() or 'update' in query.lower():
                CONNECTION.commit()
            return True, 'Success', rows
        except mysql.connector.Error as err:
            return False, err, []
    else:
        return False, '', []

# Quán lý đường dẫn assets
def relative_to_assets(path: str, type: int ) -> Path:
    return ASSETS_PATH[type] / Path(path)

# Tính khoảng cách để các hộp thoại dialog xuất hiện ở giữa màn hình
def show_center(window):
    width = window.winfo_reqwidth()
    height = window.winfo_reqheight()
    x = (window.winfo_screenwidth() - width) // 2
    y = (window.winfo_screenheight() - height) // 2
    window.geometry(f"+{x}+{y}")

# Hộp thoại dialog dùng để thông báo
def show_dialog(text):
    global window
    dialog = Toplevel(window)
    dialog.title("Dialog")
    label = Label(dialog, text=text)
    label.pack(padx=20, pady=20)
    close_button = Button(dialog, text="Đóng", command=dialog.destroy)
    close_button.pack(pady=10)
    show_center(dialog)
    dialog.mainloop()

# Giao diện login
def show_login(window):
    # Hàm xử lý sự kiện khi nhấn vào nút login
    def login(email, password):
        global USER_ID
        if '@' not in email:
            show_dialog("Email không hợp lệ")
        else:
            # Truy vấn lấy mật khẩu và mã số khách hàng để kiểm tra xác thực
            query = f"SELECT MatKhau, MSKH FROM KHACHHANG WHERE EMail = '{email}'"
            ck, debug, data = execute_querry(query)
            if len(data) > 0:
                if list(data[0])[0] == password:
                    USER_ID = list(data[0])[1]
                    show_find(window)
                else:
                    show_dialog('Sai mật khẩu')
            else:
                show_dialog('Email chưa đăng ký')

    window.geometry("700x450")
    window.configure(bg="#FFFFFF")
    window.lift()
    canvas = Canvas(window, bg="#FFFFFF", height=450, width=700, bd=0, highlightthickness=0, relief="ridge")
    canvas.place(x=0, y=0)
    image_image_1 = PhotoImage(file=relative_to_assets("image_1.png", 1))
    image_1 = canvas.create_image(144.0, 225.0, image=image_image_1)
    image_image_2 = PhotoImage(file=relative_to_assets("image_2.png", 1))
    image_2 = canvas.create_image(481.0, 225.0, image=image_image_2)
    canvas.create_text(343.0, 132.0, anchor="nw", text="Email", fill="#000000", font=("Calibri Bold", 14 * -1))
    canvas.create_text(342.0, 208.0, anchor="nw", text="Password", fill="#000000", font=("Calibri Bold", 14 * -1))
    canvas.create_text( 403.0, 38.0, anchor="nw", text="Login", fill="#000000", font=("Calibri Bold", 64 * -1))
    image_image_3 = PhotoImage(file=relative_to_assets("image_3.png", 1))
    image_3 = canvas.create_image (481.0, 173.0, image=image_image_3)
    image_image_4 = PhotoImage (file=relative_to_assets("image_4.png", 1))
    image_4 = canvas.create_image (480.0, 249.0, image=image_image_4)
    entry_image_1 = PhotoImage (file=relative_to_assets("entry_1.png", 1))
    entry_bg_1 = canvas.create_image (481.5, 173.0, image=entry_image_1)
    entry_1 = Entry(bd=0, bg="#FFFFFF", fg="#000716", highlightthickness=0)
    entry_1.place (x=350.0, y=162.0, width=263.0, height=20.0)
    entry_image_2 = PhotoImage (file=relative_to_assets("entry_2.png", 1))
    entry_bg_2 = canvas.create_image (481.5, 249.0, image=entry_image_2)
    entry_2 = Entry (bd=0, bg="#FFFFFF", fg="#000716", highlightthickness=0, show='*')
    entry_2.place (x=350.0, y=238.0, width=263.0, height=20.0)
    button_image_1 = PhotoImage (file=relative_to_assets("button_1.png", 1))
    button_1 = Button (image=button_image_1, borderwidth=0, highlightthickness=0, command=lambda: login(entry_1.get(), entry_2.get()), relief="flat")
    button_1.place (x=391.0, y=289.0, width=180.0, height=45.0)
    canvas.create_text (347.0, 353.0, anchor="nw", text="Do not have an account ?", fill="#000000", font=("Calibri Light", 14 * -1))
    button_image_2 = PhotoImage (file=relative_to_assets("button_2.png", 1))
    button_2 = Button (image=button_image_2, borderwidth=0, highlightthickness=0, command=lambda: show_register(window), relief="flat")
    button_2.place (x=514.0, y=353.0, width=99.0, height=17.0)
    canvas.create_text(347.0, 378.0, anchor="nw", text="Log in as an employee ... ", fill="#000000", font=("Calibri Light", 14 * -1))
    button_image_3 = PhotoImage(file=relative_to_assets("button_3.png", 5))
    button_3 = Button(image=button_image_3, borderwidth=0, highlightthickness=0, command=lambda: show_loginc(window), relief="flat")
    button_3.place(x=514.0, y=378.0, width=99.0, height=17.0)
    window.resizable(False, False)
    window.mainloop()



def show_register(window):
    # Hàm xử lý sự kiện khi nhấn vào nút tạo tài khoản (Create account)
    def create_account(name, email, password, repassword):
        if password != repassword:
            show_dialog('Mật khẩu không trùng khớp')
        elif name == '' or email == '' or password == '':
            show_dialog("Không được để trống thông tin")
        elif '@' not in email:
            show_dialog('Email không hợp lệ')
        else:
            # Truy vấn thêm dữ liệu khach hàng vào cơ sở dữ liệu
            query = f"INSERT INTO KhachHang(HoTenKH, EMail, MatKhau) VALUES ('{name}', '{email}', '{password}')"
            ck, debug, data = execute_querry(query)
            show_dialog(debug)
    window.geometry("700x450")
    window.configure(bg="#FFFFFF")
    window.lift()
    canvas = Canvas(window, bg="#FFFFFF", height=450, width=700, bd=0, highlightthickness=0, relief="ridge")
    canvas.place(x=0, y=0)
    image_image_1 = PhotoImage(file=relative_to_assets("image_1.png", 2))
    image_1 = canvas.create_image(144.0, 225.0, image=image_image_1)
    image_image_2 = PhotoImage(file=relative_to_assets("image_2.png", 2))
    image_2 = canvas.create_image(481.0, 225.0, image=image_image_2)
    canvas.create_text(336.0, 92.0, anchor="nw", text="Name", fill="#000000", font=("Calibri Bold", 14 * -1))
    canvas.create_text(337.0, 145.0, anchor="nw", text="Email", fill="#000000", font=("Calibri Bold", 14 * -1))
    canvas.create_text(337.0, 207.0, anchor="nw", text="Password", fill="#000000", font=("Calibri Bold", 14 * -1))
    canvas.create_text(337.0, 266.0, anchor="nw", text="Confirm Password", fill="#000000", font=("Calibri Bold", 14 * -1))
    canvas.create_text(312.0, 15.0, anchor="nw", text="Create Account", fill="#000000", font=("Calibri Bold", 48 * -1))
    image_image_3 = PhotoImage(file=relative_to_assets("image_4.png", 2))
    image_3 = canvas.create_image(475.0, 126.0, image=image_image_3)
    image_image_4 = PhotoImage(file=relative_to_assets("image_3.png", 2))
    image_4 = canvas.create_image(474.0, 181.0, image=image_image_4)
    image_image_5 = PhotoImage(file=relative_to_assets("image_5.png", 2))
    image_5 = canvas.create_image(475.0, 241.0, image=image_image_5)
    image_image_6 = PhotoImage(file=relative_to_assets("image_6.png", 2))
    image_6 = canvas.create_image(474.0, 299.0, image=image_image_6)
    entry_image_1 = PhotoImage(file=relative_to_assets("entry_1.png", 2))
    entry_bg_1 = canvas.create_image(474.5, 124.0, image=entry_image_1)
    entry_1 = Entry(bd=0, bg="#FFFFFF", fg="#000716", highlightthickness=0)
    entry_1.place(x=343.0, y=113.0, width=263.0, height=20.0)
    entry_image_2 = PhotoImage(file=relative_to_assets("entry_2.png", 2))
    entry_bg_2 = canvas.create_image(473.5, 181.0, image=entry_image_2)
    entry_2 = Entry(bd=0, bg="#FFFFFF", fg="#000716", highlightthickness=0)
    entry_2.place(x=342.0, y=170.0, width=263.0, height=20.0)
    entry_image_3 = PhotoImage(file=relative_to_assets("entry_3.png", 2))
    entry_bg_3 = canvas.create_image(473.5, 241.0, image=entry_image_3)
    entry_3 = Entry(bd=0, bg="#FFFFFF", fg="#000716", highlightthickness=0, show='*')
    entry_3.place(x=342.0, y=230.0, width=263.0, height=20.0)
    entry_image_4 = PhotoImage(file=relative_to_assets("entry_4.png", 2))
    entry_bg_4 = canvas.create_image(474.5, 299.0, image=entry_image_4)
    entry_4 = Entry(bd=0, bg="#FFFFFF", fg="#000716", highlightthickness=0, show='*')
    entry_4.place(x=343.0, y=288.0, width=263.0, height=20.0)
    button_image_1 = PhotoImage(file=relative_to_assets("button_1.png", 2))
    button_1 = Button(image=button_image_1, borderwidth=0, highlightthickness=0, relief="flat",
                      command=lambda: create_account(entry_1.get(), entry_2.get(), entry_3.get(), entry_4.get()))
    button_1.place(x=390.0, y=333.0, width=180.0, height=45.0)
    canvas.create_text(355.0, 398.0, anchor="nw", text="Have an account already?", fill="#000000", font=("Calibri Light", 14 * -1))
    button_image_2 = PhotoImage(file=relative_to_assets("button_2.png", 2))
    button_2 = Button(image=button_image_2, borderwidth=0, highlightthickness=0, command=lambda: show_login(window), relief="flat")
    button_2.place(x=521.0, y=398.0, width=99.0, height=17.0)
    window.resizable(False, False)
    window.mainloop()

# Xóa dữ liệu bảng
def clear_table(table: Tableview):
    table.delete_rows()

# Chuyển ngày từ năm - tháng - ngày thành ngày - tháng - năm
# Ví dụ: 2023-12-31 thành 31-12-2023
def chuyen_ngay(value):
    value = value.split("-")
    return value[2] + "-" + value[1] + "-" + value[0]

# Chuyển ngày từ ngày - tháng - năm thành năm - tháng - ngày
# Ví dụ:  31-12-2023 thành 2023-12-31
def dinh_dang_ngay(value):
    value = value.split("-")
    return value[2] + "/" + value[1] + "/" + value[0]

# Chuyển định dạng biến datetime thành giờ - phút - giây
def datetime_to_string(delta_time):
    hours, remainder = divmod(delta_time.seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    return f"{hours:02}:{minutes:02}:{seconds:02}"

# Chuyển đổi các dữ liệu thành chuỗi để hiển thị trên bảng tìm xe
def convert_data_table(data, nv=False):
    new_data = []
    for d in data:
        row = list(d)
        row[5] = datetime_to_string(row[5])
        row[6] = datetime_to_string(row[6])
        if row[10] != "Chưa có" and nv is False:
            row[10] = str(row[10]) + "/10.0"
        row[11] = row[11].decode('utf-8')
        new_data.append(row)
    return new_data

# Cập nhật lại bảng thông qua biến toàn cục QUERY sau khi đặt vé xong
def update_find_table(table, nv=False):
    global QUERY
    clear_table(table)
    ck, debug, data = execute_querry(QUERY)
    data_table = convert_data_table(data, nv)
    for row in data_table:
        table.insert_row('end', row)
        table.load_table_data()

# Hộp thoại đặt vém data1 chứa dữ liệu chuyến xe, data2 chứa dữ liệu vé xe
def xac_nhan_dat_ve(data1, data2):
    thong_tin = (f"Mã Chuyến Xe : {data1[0]}\n"
                 f"Nhà Xe : {data1[1]}\n"
                 f"Loại Xe : {data1[2]}\n"
                 f"Xuất Phát : {data1[3]}\n"
                 f"Điểm Đến : {data1[4]}\n"
                 f"Giờ Đi    : {data1[5]}\n"
                 f"Giờ Đến : {data1[6]}\n"
                 f"Biển Số : {data1[7]}\n"
                 f"Mã Vé : {data2[0]}\n"
                 f"Số Ghế : {data2[1]}\n"
                 f"Giá tiền : {data2[2]}\n")
    result = messagebox.askokcancel("Xác Nhận Đặt Vé", thong_tin)
    if result:
        return True
    else:
        return False

# Giao diện Tim Xe
def show_find(window):
    window.geometry("900x540")
    window.configure(bg="#FFFFFF")
    window.lift()

    canvas = Canvas(window, bg="#FFFFFF", height=540, width=900, bd=0, highlightthickness=0, relief="ridge")
    canvas.place(x=0, y=0)
    canvas2 = Canvas(window, width=890, height=700)
    canvas2.place(x=15, y=65)

    cal = DateEntry(bootstyle="success", dateformat=r"%d-%m-%Y")
    cal.place(x=325, y=380)
    cb1 = Combobox(bootstyle="success", state="readonly", values=['Hà Nội', 'Hạ Long', 'Ninh Bình'])
    cb1.current(0)
    cb1.place(x=325, y=430, w=160)
    cb2 = Combobox(bootstyle="success", state="readonly", values=['Hà Nội', 'Hạ Long', 'Ninh Bình'])
    cb2.current(1)
    cb2.place(x=325, y=480, w=160)

    coldata = [
        {"text": "Mã CX", "stretch": False, 'width': 50},
        {"text": "Nhà Xe", "stretch": False, 'width': 90},
        {"text": "Loại Xe", "stretch": False, 'width': 170},
        {"text": "Xuất Phát", "stretch": False, 'width': 70},
        {"text": "Điểm Đến", "stretch": False, 'width': 70},
        {"text": "Giờ Đi", "stretch": False, 'width': 60},
        {"text": "Giờ Đến", "stretch": False, 'width': 60},
        {"text": "Biển Số", "stretch": False, 'width': 58},
        {"text": "Trống", "stretch": False, 'width': 50},
        {"text": "Liên Hệ", "stretch": False, 'width': 70},
        {"text": "Đánh Giá", "stretch": False, 'width': 70},
        {"text": "Lượt", "stretch": False, 'width': 40},
    ]

    table = Tableview(master=canvas2, coldata=coldata, rowdata=[], paginated=True, pagesize=13, autofit=False, searchable=False, bootstyle=SUCCESS, height=13)
    table.pack(fill=BOTH, expand=YES, padx=0, pady=0)
    table.load_table_data()

    # Hàm xử lý sự kiện khi nhấn vào nút tìm kiếm
    def tim_kiem(diem_bat_dau, diem_den, ngay_dv):
        global QUERY
        ngay_dv = chuyen_ngay(ngay_dv)
        QUERY = (f"SELECT A.MaCX, E.TenNX, CONCAT(CONCAT(CONCAT(D.TenLoai, ' '), D.SoTang), ' Tầng'), "
                 f"B.DiemBatDau, B.DiemKetThuc, A.GioKhoiHanh, A.GioCapBen, C.BienSo, "
                 f"A.SoGheTrong - CAST(COALESCE("
                 f"(SELECT COUNT(*) FROM DatVeXe G, VeXe H "
                 f"WHERE A.MaCX = H.MaCX "
                 f"AND G.MaVX = H.MaVX "
                 f"AND H.NgayXeChay = '{ngay_dv}' "
                 f"AND G.TrangThai = 'Đã Đặt'), "
                 f"'0') AS SIGNED) AS SoVeXe, "
                 f"E.SoDienThoai, "
                 f"COALESCE(ROUND((SELECT AVG(F.SoDiem) FROM DanhGia F, VeXe G WHERE A.MaCX = G.MaCX AND F.MaVX = G.MaVX), 1), 'Chưa có') AS DiemTrungBinh, "
                 f"COALESCE((SELECT COUNT(*) FROM DanhGia F, VeXe G WHERE A.MaCX = G.MaCX AND F.MaVX = G.MaVX), 'Chưa có') AS SoLuotDanhGia "
                 f"FROM ChuyenXe A, TuyenDuong B, Xe C, LoaiXe D, NhaXe E "
                 f"WHERE A.MaTD = B.MaTD AND	A.MaXe = C.MaXe AND C.MaLoai = D.MaLoai AND C.MSNX = E.MSNX "
                 f"AND LOWER(B.DiemBatDau) = LOWER('{diem_bat_dau}') "
                 f"AND LOWER(B.DiemKetThuc) = LOWER('{diem_den}')")
        print(QUERY)
        update_find_table(table)

    # Hàm xử lý sự kiện khi nhấn vào nút tìm kiếm theo tên nhà xe
    def tim_theo_ten_nha_xe(diem_bat_dau, diem_den, ten_nha_xe, ngay_dv):
        global QUERY
        ngay_dv = chuyen_ngay(ngay_dv)
        QUERY = (f"SELECT A.MaCX, E.TenNX, CONCAT(CONCAT(CONCAT(D.TenLoai, ' '), D.SoTang), ' Tầng'), "
                 f"B.DiemBatDau, B.DiemKetThuc, A.GioKhoiHanh, A.GioCapBen, C.BienSo, "
                 f"A.SoGheTrong - CAST(COALESCE("
                 f"(SELECT COUNT(*) FROM DatVeXe G, VeXe H "
                 f"WHERE A.MaCX = H.MaCX "
                 f"AND G.MaVX = H.MaVX "
                 f"AND H.NgayXeChay = '{ngay_dv}' "
                 f"AND G.TrangThai = 'Đã Đặt'), "
                 f"'0') AS SIGNED) AS SoVeXe, "
                 f"E.SoDienThoai, "
                 f"COALESCE(ROUND((SELECT AVG(F.SoDiem) FROM DanhGia F, VeXe G WHERE A.MaCX = G.MaCX AND F.MaVX = G.MaVX), 1), 'Chưa có') AS DiemTrungBinh, "
                 f"COALESCE((SELECT COUNT(*) FROM DanhGia F, VeXe G WHERE A.MaCX = G.MaCX AND F.MaVX = G.MaVX), 'Chưa có') AS SoLuotDanhGia "
                 f"FROM ChuyenXe A, TuyenDuong B, Xe C, LoaiXe D, NhaXe E "
                 f"WHERE A.MaTD = B.MaTD AND	A.MaXe = C.MaXe AND C.MaLoai = D.MaLoai AND C.MSNX = E.MSNX "
                 f"AND LOWER(B.DiemBatDau) = LOWER('{diem_bat_dau}') "
                 f"AND LOWER(B.DiemKetThuc) = LOWER('{diem_den}')"
                 f"AND LOWER(E.TenNX) = LOWER('{ten_nha_xe}')")
        update_find_table(table)

    # Hàm xử lý sự kiện khi nhấn vào nút tìm kiếm theo số điện thoại nhà xe
    def tim_theo_sdt_nha_xe(diem_bat_dau, diem_den, sdt_nha_xe, ngay_dv):
        global QUERY
        ngay_dv = chuyen_ngay(ngay_dv)
        QUERY = (f"SELECT A.MaCX, E.TenNX, CONCAT(CONCAT(CONCAT(D.TenLoai, ' '), D.SoTang), ' Tầng'), "
                 f"B.DiemBatDau, B.DiemKetThuc, A.GioKhoiHanh, A.GioCapBen, C.BienSo, "
                 f"A.SoGheTrong - CAST(COALESCE("
                 f"(SELECT COUNT(*) FROM DatVeXe G, VeXe H "
                 f"WHERE A.MaCX = H.MaCX "
                 f"AND G.MaVX = H.MaVX "
                 f"AND H.NgayXeChay = '{ngay_dv}' "
                 f"AND G.TrangThai = 'Đã Đặt'), "
                 f"'0') AS SIGNED) AS SoVeXe, "
                 f"E.SoDienThoai, "
                 f"COALESCE(ROUND((SELECT AVG(F.SoDiem) FROM DanhGia F, VeXe G WHERE A.MaCX = G.MaCX AND F.MaVX = G.MaVX), 'Chưa có') AS DiemTrungBinh, "
                 f"COALESCE((SELECT COUNT(*) FROM DanhGia F, VeXe G WHERE A.MaCX = G.MaCX AND F.MaVX = G.MaVX), 'Chưa có') AS SoLuotDanhGia "
                 f"FROM ChuyenXe A, TuyenDuong B, Xe C, LoaiXe D, NhaXe E "
                 f"WHERE A.MaTD = B.MaTD AND	A.MaXe = C.MaXe AND C.MaLoai = D.MaLoai AND C.MSNX = E.MSNX "
                 f"AND LOWER(B.DiemBatDau) = LOWER('{diem_bat_dau}') "
                 f"AND LOWER(B.DiemKetThuc) = LOWER('{diem_den}')"
                 f"AND LOWER(E.SoDienThoai) = LOWER('{sdt_nha_xe}')")
        update_find_table(table)

    # Hàm xử lý sự kiện khi nhấn vào nút hiển thị tất cả
    def hien_thi_tat_ca(ngay_dv):
        global QUERY
        ngay_dv = chuyen_ngay(ngay_dv)
        QUERY = (f"SELECT A.MaCX, E.TenNX, CONCAT(CONCAT(CONCAT(D.TenLoai, ' '), D.SoTang), ' Tầng'), "
                 f"B.DiemBatDau, B.DiemKetThuc, A.GioKhoiHanh, A.GioCapBen, C.BienSo, "
                 f"A.SoGheTrong - CAST(COALESCE("
                 f"(SELECT COUNT(*) FROM DatVeXe G, VeXe H "
                 f"WHERE A.MaCX = H.MaCX "
                 f"AND G.MaVX = H.MaVX "
                 f"AND H.NgayXeChay = '{ngay_dv}' "
                 f"AND G.TrangThai = 'Đã Đặt'), "
                 f"'0') AS SIGNED) AS SoVeXe, "
                 f"E.SoDienThoai, "
                 f"COALESCE(ROUND((SELECT AVG(F.SoDiem) FROM DanhGia F, VeXe G WHERE A.MaCX = G.MaCX AND F.MaVX = G.MaVX), 1), 'Chưa có') AS DiemTrungBinh, "
                 f"COALESCE((SELECT COUNT(*) FROM DanhGia F, VeXe G WHERE A.MaCX = G.MaCX AND F.MaVX = G.MaVX), 'Chưa có') AS SoLuotDanhGia "
                 f"FROM ChuyenXe A, TuyenDuong B, Xe C, LoaiXe D, NhaXe E "
                 f"WHERE A.MaTD = B.MaTD AND	A.MaXe = C.MaXe AND C.MaLoai = D.MaLoai AND C.MSNX = E.MSNX ")
        update_find_table(table)

    # Hàm xử lý sự kiện khi nhấn vào nút đặt vé
    def dat_ve(ngay_dv):
        global USER_ID
        global QUERY
        # Kiểm tra ngày hiện tại có vượt qua ngày đặt vé không
        ngay_dv = chuyen_ngay(ngay_dv)
        row_selected = table.get_rows(selected=True)
        ngay_hien_tai = datetime.now().date()
        gio_hien_tai = datetime.now().time()
        ngay_hien_tai = ngay_hien_tai.strftime("%Y-%m-%d")
        if ngay_hien_tai > ngay_dv:
            show_dialog("Vé đã hết hạn")
            return
        if len(row_selected) > 0:
            data = row_selected[0].values
            # Kiểm tra nếu chung 1 ngày thì xem số giờ trươc ssau
            if ngay_hien_tai == ngay_dv:
                gio_xuat_phat = datetime.strptime(data[5], "%H:%M:%S").time()
                if gio_hien_tai > gio_xuat_phat:
                    show_dialog("Vé hết hạn vài tiếng trước rồi")
                    return
            if data[8] == 0:
                show_dialog("Xe này hết ghế trống rồi")
            else:
                # Thực hiện Truy vấn để kiểm tra tất các vé xe phù hợp với thời gian và chuyến đi
                query = (f"SELECT A.MaVX, A.MaCX, A.GiaVe, A.SoGhe, A.NgayXeChay "
                         f"FROM VeXe A "
                         f"WHERE A.MaCX = '{data[0]}' AND A.NgayXeChay = '{ngay_dv}'")
                ck, debug, vexe = execute_querry(query)
                kiem_tra_ve_trong, MaVX, SoGhe, GiaVe = False, None, None, None
                for d in vexe:
                    # Thực hiện truy vấn để kiểm tra vé xe có được đặt hay chưa ?
                    query2 = f"SELECT * FROM DatVeXe WHERE MaVX = '{d[0]}' AND TrangThai = 'Đã Đặt'"
                    _, _, data2 = execute_querry(query2)
                    if len(data2) == 0:
                        # Nếu tồn tại vé xe mà chưa được đặt thì sẽ chọn vé xe đó
                        kiem_tra_ve_trong, MaVX, SoGhe, GiaVe = True, d[0], d[3], d[2]
                if kiem_tra_ve_trong == True:
                    if xac_nhan_dat_ve(data, [MaVX, SoGhe, GiaVe]):
                        # Thực hiện truy vấn để đặt vé xe
                        query3 = f"INSERT INTO DatVeXe(MaVX, MSKH) VALUE('{MaVX}', '{USER_ID}')"
                        _, _, _ = execute_querry(query3)
                else:
                    # Nếu ko có vé xe phù hợp và còn chỗ trống thì sẽ kiểm tra xe có bao nhiêu ghế để tiến hành tạo vé
                    query3 = (f"SELECT B.SoGhe FROM Xe A, LoaiXe B, ChuyenXe C "
                              f"WHERE A.MaXe = C.MaXe AND A.MaLoai = B.MaLoai AND C.MaCX = '{data[0]}'")
                    _, _, tong_so_ghe = execute_querry(query3)
                    tong_so_ghe = list(tong_so_ghe[0])[0]
                    while True:
                        # Thực hiện chọn số ghế ngẫu nhiên để tạo vé từ 1 đến tổng số ghế
                        soghe = random.randint(1, int(tong_so_ghe))
                        # Kiểm tra số ghế sau khi chọn ngẫu nhiên có tồn tại chưa ?
                        query4 = (f"SELECT A.SoGhe FROM VeXe A, DatVeXe B, ChuyenXe C "
                                  f"WHERE A.MaCX = C.MaCX AND A.MaVX = B.MaVX AND A.SoGhe = '{soghe}'"
                                  f"AND C.MaCX = '{data[0]}' AND B.TrangThai = '0' AND A.NgayXeChay = '{ngay_dv}'")
                        _, _, so_ghe_da_dat = execute_querry(query4)
                        if len(so_ghe_da_dat) == 0:
                            # Nếu ko tìm đc tức là số ghế còn trống sẽ tiến hành tạo vé
                            # Nếu tìm đc tức số ghé đã đc đặt rồi sẽ random số khác thông qua vòng lặp while True
                            ngay_xe_chay = dinh_dang_ngay(ngay_dv)

                            # Truy vấn tạo vé xe mới
                            query5 = (f"INSERT INTO VeXe(MaCX, GiaVe, SoGhe, NgayXeChay) "
                                      f"VALUES('{data[0]}', '500', '{soghe}', STR_TO_DATE('{ngay_xe_chay}', '%d/%m/%Y'))")
                            _, _, _ = execute_querry(query5)
                            # Truy vấn kiểm tra vé xe có được tạo thành công chưa ?
                            query6 = (f"SELECT MaVX FROM VeXe WHERE MaCX = '{data[0]}' "
                                      f"AND NgayXeChay = '{ngay_dv}' AND SoGhe = '{soghe}'")
                            _, _, mavx = execute_querry(query6)
                            if len(mavx) == 0:
                                # Nếu ko thành công tạo vé sẽ báo lỗi
                                show_dialog("Không thể tạo vé")
                            else:
                                # Nếu thành công sẽ hiển thị hộp thoại xác nhận đặt vé lần nữa
                                mavx = list(mavx[0])[0]
                                if xac_nhan_dat_ve(data, [mavx, soghe, '500']) is True:
                                    # Nếu người dùng chon OKe thì sẽ tiến hành đặt vé, nếu ko chọn OKE thì sẽ có vé trống
                                    query3 = f"INSERT INTO DatVeXe(MaVX, MSKH) VALUE('{mavx}', '{USER_ID}')"
                                    _, _, _ = execute_querry(query3)
                                    break
                                else:
                                    break
        else:
            show_dialog("Chưa chọn chuyến xe")
        update_find_table(table)

    # Hàm xử lý sự kiện khi nhấn vào nút xem bình luận
    def xem_binh_luan():
        # Tạo cửa sổ dialog
        row_selected = table.get_rows(selected=True)
        if len(row_selected) > 0:
            table_dialog = Toplevel(window)
            table_dialog.title("Đánh giá và Bình luận")
            table_dialog.transient(window)
            table_dialog.resizable(False, False)

            coldata = [{"text": "Tên", "stretch": False, 'width': 100},
                       {"text": "Bình Luận", "stretch": False, 'width': 250},
                       {"text": "Đánh Giá", "stretch": False, 'width': 70}]

            table2 = Tableview(master=table_dialog, coldata=coldata, rowdata=[], paginated=True, pagesize=10, autofit=False, searchable=False, bootstyle=SUCCESS, height=10)
            table2.pack(fill=BOTH, expand=YES, padx=0, pady=0)
            table2.load_table_data()

            MaCX = list(row_selected[0].values)[0]
            # Thực hiện truy vấn để lấy các dữ liệu cho bảng bình luận
            query = (f"SELECT A.HoTenKH, B.MoTa, B.SoDiem "
                     f"FROM KhachHang A, DanhGia B, VeXe G "
                     f"WHERE G.MaCX = '{MaCX}' AND A.MSKH = B.MSKH AND B.MaVX = G.MaVX")
            _, _, data = execute_querry(query)
            for d in data:
                row = list(d)
                if row[1] == '':
                    row[1] = 'Không bình luận'
                table2.insert_row('end', row)
                table2.load_table_data()

            def ok_button_callback():
                table_dialog.destroy()

            ok_button = BButton(table_dialog, bootstyle="success", text="OK", command=ok_button_callback)
            ok_button.pack(pady=10)
            show_center(table_dialog)
        else:
            show_dialog("Vui lòng chọn chuyến xe để xem")

    image_image_1 = PhotoImage(file=relative_to_assets("image_1.png", 3))
    image_1 = canvas.create_image(450.0, 270.0, image=image_image_1)
    image_image_2 = PhotoImage(file=relative_to_assets("image_2.png", 3))
    image_2 = canvas.create_image(450.0, 22.0, image=image_image_2)
    image_image_3 = PhotoImage(file=relative_to_assets("image_3.png", 3))
    image_3 = canvas.create_image(448.0, 207.0, image=image_image_3)
    image_image_4 = PhotoImage(file=relative_to_assets("image_4.png", 3))
    image_4 = canvas.create_image(448.0, 22.0, image=image_image_4)
    image_image_5 = PhotoImage(file=relative_to_assets("image_5.png", 3))
    image_5 = canvas.create_image(135.00000655651093, 386.0, image=image_image_5)
    image_image_6 = PhotoImage(file=relative_to_assets("image_6.png", 3))
    image_6 = canvas.create_image(263.0, 402.0, image=image_image_6)
    image_image_7 = PhotoImage(file=relative_to_assets("image_7.png", 3))
    image_7 = canvas.create_image(589.0, 400, image=image_image_7)
    image_image_8 = PhotoImage(file=relative_to_assets("image_8.png", 3))
    image_8 = canvas.create_image(263.0, 447.0, image=image_image_8)
    image_image_9 = PhotoImage(file=relative_to_assets("image_9.png", 3))
    image_9 = canvas.create_image(244.0, 495, image=image_image_9)
    image_image_10 = PhotoImage(file=relative_to_assets("image_10.png", 3))
    image_10 = canvas.create_image(495.0, 448.99836237504496, image=image_image_10)
    image_image_11 = PhotoImage(file=relative_to_assets("image_11.png", 3))
    image_11 = canvas.create_image(541.0, 448.0, image=image_image_11)

    # image_image_1 = PhotoImage(file=relative_to_assets("image_1.png", 3))
    # image_1 = canvas.create_image(225.0, 22.0, image=image_image_1)
    # canvas.create_text(177.0, 10.0, anchor="nw", text="Tìm Xe", fill="#000000", font=("Arial BoldMT", 24 * -1))
    # button_image_1 = PhotoImage(file=relative_to_assets("button_1.png", 3))
    # button_1 = Button(image=button_image_1, borderwidth=0, highlightthickness=0, command=lambda: show_info(window), relief="flat")
    # button_1.place(x=450.0, y=0.0, width=450.0, height=45.0)


    entry_1 = BEntry(bootstyle="success")
    entry_1.place(x=680, y=380, width=195)
    button_2 = BButton(bootstyle="success", text="Tìm Kiếm", command=lambda: tim_kiem(cb1.get(), cb2.get(), cal.entry.get()))
    button_2.place(x=510, y=430, w=115)
    button_3 = BButton(bootstyle="success", text="Tìm Theo Nhà Xe", command=lambda: tim_theo_ten_nha_xe(cb1.get(), cb2.get(), entry_1.get(), cal.entry.get()))
    button_3.place(x=635, y=430, w=115)
    button_4 = BButton(bootstyle="success", text="Tìm Theo SDT", command=lambda: tim_theo_sdt_nha_xe(cb1.get(), cb2.get(), entry_1.get(), cal.entry.get()))
    button_4.place(x=760, y=430, w=115)
    button_5 = BButton(bootstyle="primary", text="Tìm Tất Cả", command=lambda: hien_thi_tat_ca(cal.entry.get()))
    button_5.place(x=510, y=480, w=115)
    button_6 = BButton(bootstyle="warning", text="Xem Bình Luận", command=lambda: xem_binh_luan())
    button_6.place(x=635, y=480, w=115)
    button_7 = BButton(bootstyle="danger", text="Đặt Vé", command=lambda: dat_ve(cal.entry.get()))
    button_7.place(x=760, y=480, w=115)

    def stuff(x):
        if x == 'Đăng Nhập Tài Khoản Khác':
            show_login(window)
        elif x == 'Lịch Sử Chuyến Đi':
            show_info(window)
        elif x == 'Quản Lý Chuyến Xe (Login EMP)':
            show_loginc(window)
        else:
            pass
    my_menu = BMenubutton(bootstyle="dark-outline", text="Menu")
    my_menu.place(x=5, y=5)
    inside_menu = BMenu(my_menu)
    item_var = StringVar()
    for x in ['Đăng Nhập Tài Khoản Khác', 'Tìm Xe', 'Lịch Sử Chuyến Đi', 'Quản Lý Chuyến Xe (Login EMP)']:
        inside_menu.add_radiobutton(label=x, variable=item_var, command=lambda x=x: stuff(x))
    my_menu['menu'] = inside_menu
    window.resizable(False, False)
    window.mainloop()

# Hàm load dữ liệu cho bảng của giao diện lịch sử chuyến đi
def thong_tin_user(table):
    global USER_ID
    clear_table(table)
    # Truy vấn lấy dữ liệu cho bảng
    query = (f"SELECT F.MaDV, E.TenNX, CONCAT(CONCAT(CONCAT(D.TenLoai, ' '), D.SoTang), ' Tầng'), "
             f"B.DiemBatDau, B.DiemKetThuc, H.NgayXeChay, A.GioKhoiHanh, A.GioCapBen, C.BienSo, "
             f"H.SoGhe, H.GiaVe, F.TrangThai "
             f"FROM ChuyenXe A, TuyenDuong B, Xe C, LoaiXe D, NhaXe E, VeXe H, DatVeXe F "
             f"WHERE A.MaCX = H.MaCX AND A.MaTD = B.MaTD AND A.MaXe = C.MaXe AND F.MaVX = H.MaVX "
             f"AND C.MaLoai = D.MaLoai AND C.MSNX = E.MSNX AND F.MSKH = '{USER_ID}'")
    ck, debug, data = execute_querry(query)
    for d in data:
        row = list(d)
        row[5] = row[5].strftime("%d/%m/%Y")
        row[6] = datetime_to_string(row[6])
        row[7] = datetime_to_string(row[7])
        table.insert_row('end', row)
        table.load_table_data()

# Hàm hiển thị thông tin hủy vé chuyến xe nào và yêu cầu xác nhận
def xac_nhan_huy_ve(ma_dv):
    global USER_ID
    # Truy vấn lấy dữ liệu
    query = (f"SELECT F.MaDV, E.TenNX, CONCAT(CONCAT(CONCAT(D.TenLoai, ' '), D.SoTang), ' Tầng'), "
             f"B.DiemBatDau, B.DiemKetThuc, H.NgayXeChay, A.GioKhoiHanh, A.GioCapBen, C.BienSo, "
             f"H.SoGhe, H.GiaVe "
             f"FROM ChuyenXe A, TuyenDuong B, Xe C, LoaiXe D, NhaXe E, VeXe H, DatVeXe F "
             f"WHERE F.MaDV = '{ma_dv}' AND A.MaCX = H.MaCX AND A.MaTD = B.MaTD AND A.MaXe = C.MaXe "
             f"AND F.MaVX = H.MaVX AND C.MaLoai = D.MaLoai AND C.MSNX = E.MSNX AND F.MSKH = '{USER_ID}'")
    ck, debug, data = execute_querry(query)
    data1 = list(data[0])
    data1[5] = data1[5].strftime("%d/%m/%Y")
    data1[6] = datetime_to_string(data1[6])
    data1[7] = datetime_to_string(data1[7])
    thong_tin = (f"Mã Đặt Vé : {data1[0]}\n"
                 f"Nhà Xe : {data1[1]}\n"
                 f"Loại Xe : {data1[2]}\n"
                 f"Xuất Phát : {data1[3]}\n"
                 f"Điểm Đến : {data1[4]}\n"
                 f"Ngày Đi : {data1[5]}\n"
                 f"Giờ Đi    : {data1[6]}\n"
                 f"Giờ Đến : {data1[7]}\n"
                 f"Biển Số : {data1[8]}\n"
                 f"Số Ghế : {data1[9]}\n"
                 f"Giá tiền : {data1[10]}\n")
    result = messagebox.askokcancel("Xác Nhận Hủy Vé", thong_tin)
    if result:
        return True
    else:
        return False

# Hàm hiển thị hộp thoại đánh giá và bình luận cho khách hàng
def show_review_dialog(root, ma_dv):
    global USER_ID
    query = (f"SELECT H.MaVX FROM VeXe H, DatVeXe F, DanhGia G "
             f"WHERE F.MaDV = '{ma_dv}' AND F.MaVX = H.MaVX AND F.MSKH = '{USER_ID}'")
    ck, debug, data = execute_querry(query)
    ma_vx = list(data[0])[0]

    # Tạo cửa sổ đánh giá và bình luận
    rating_window = Toplevel(root)
    rating_window.transient(root)
    rating_window.title("Đánh giá và Bình luận")
    rating_window.resizable(False, False)

    # Label và Scale cho đánh giá
    rating_label = Label(rating_window, text="Đánh giá từ 1 đến 10:")
    rating_label.pack()

    def scaler(e):
        rating_label.config(text=f'Đánh giá từ 1 đến 10: {int(rating_scale.get())}')

    rating_scale = BScale(rating_window, from_=1, to=10, orient="horizontal", length=200, command=scaler)
    rating_scale.set(10)  # Đặt giá trị mặc định là 10
    rating_scale.pack()

    # Label và Text để viết bình luận
    comment_label = Label(rating_window, text="Bình luận:")
    comment_label.pack()

    comment_text = Text(rating_window, height=5, width=30)
    comment_text.pack()


    # Hàm xử lý khi nhấn OK
    def ok_button_callback():
        global USER_ID
        rating_result = int(rating_scale.get())
        comment_result = comment_text.get("1.0", "end-1c")
        rating_window.destroy()
        query2 = (f"INSERT INTO DanhGia(MaVX, MSKH, SoDiem, MoTa) "
                  f"VALUES ('{ma_vx}', '{USER_ID}', '{rating_result}', '{comment_result}')")
        _, _, _ = execute_querry(query2)

    # Button OK và Cancel
    ok_button = Button(rating_window, text="OK", command=ok_button_callback)
    ok_button.pack(side="left", padx=10)

    cancel_button = Button(rating_window, text="Cancel", command=rating_window.destroy)
    cancel_button.pack(side="right", padx=10)

    show_center(rating_window)


# Hàm hiển thị hộp thoại thay đổi mật khẩu
def change_password_dialog(root):
    # Tạo cửa sổ đổi mật khẩu
    password_dialog = Toplevel(root)
    password_dialog.title("Đổi Mật Khẩu")
    password_dialog.transient(root)
    password_dialog.resizable(False, False)

    # Biến lưu trạng thái
    new_password_var = StringVar()
    confirm_password_var = StringVar()

    # Widget và Label nhập mật khẩu cũ
    current_password_label = Label(password_dialog, text="Nhập Mật Khẩu Cũ:")
    current_password_label.grid(row=0, column=0, padx=10, pady=5)

    current_password_entry = Entry(password_dialog, show="*")
    current_password_entry.grid(row=0, column=1, padx=10, pady=5)

    # Widget và Label nhập mật khẩu mới
    new_password_label = Label(password_dialog, text="Nhập Mật Khẩu Mới:")
    new_password_label.grid(row=1, column=0, padx=10, pady=5)

    new_password_entry = Entry(password_dialog, show="*", textvariable=new_password_var)
    new_password_entry.grid(row=1, column=1, padx=10, pady=5)

    # Widget và Label xác nhận lại mật khẩu mới
    confirm_password_label = Label(password_dialog, text="Xác Nhận Mật Khẩu Mới:")
    confirm_password_label.grid(row=2, column=0, padx=10, pady=5)

    confirm_password_entry = Entry(password_dialog, show="*", textvariable=confirm_password_var)
    confirm_password_entry.grid(row=2, column=1, padx=10, pady=5)

    # Hàm xử lý khi nhấn OK
    def ok_button_callback():
        global USER_ID
        current_password = current_password_entry.get()
        new_password = new_password_entry.get()
        confirm_password = confirm_password_entry.get()

        query = f"SELECT MatKhau FROM KhachHang WHERE MSKH = '{USER_ID}'"
        _, _, data = execute_querry(query)
        mk = list(data[0])[0]

        # Kiểm tra mật khẩu cũ và xác nhận mật khẩu mới
        if current_password == mk:  # Thay "mypass" bằng mật khẩu hiện tại của người dùng
            if new_password == confirm_password:
                messagebox.showinfo("Thông Báo", "Đổi Mật Khẩu Thành Công")
                query2 = f"UPDATE KhachHang SET MatKhau = '{new_password}' WHERE MSKH = '{USER_ID}'"
                _, _, _ = execute_querry(query2)
                password_dialog.destroy()
            else:
                messagebox.showerror("Lỗi", "Xác Nhận Mật Khẩu Mới Không Khớp")
        else:
            messagebox.showerror("Lỗi", "Mật Khẩu Cũ Không Chính Xác")

    # Button OK và Cancel
    ok_button = Button(password_dialog, text="OK", command=ok_button_callback)
    ok_button.grid(row=3, column=0, padx=10, pady=10)

    cancel_button = Button(password_dialog, text="Cancel", command=password_dialog.destroy)
    cancel_button.grid(row=3, column=1, padx=10, pady=10)
    show_center(password_dialog)

def show_info(window):
    window.geometry("900x540")
    window.configure(bg="#FFFFFF")
    window.lift()
    canvas = Canvas(window, bg="#FFFFFF", height=540, width=900, bd=0, highlightthickness=0, relief="ridge")
    canvas.place(x=0, y=0)

    canvas2 = Canvas(window, width=890, height=700)
    canvas2.place(x=15, y=58)

    coldata = [
        {"text": "Mã Vé", "stretch": False, 'width': 50},
        {"text": "Nhà Xe", "stretch": False, 'width': 70},
        {"text": "Loại Xe", "stretch": False, 'width': 160},
        {"text": "Xuất Phát", "stretch": False, 'width': 70},
        {"text": "Điểm Đến", "stretch": False, 'width': 70},
        {"text": "Ngày Đi", "stretch": False, 'width': 70},
        {"text": "Giờ Đi", "stretch": False, 'width': 60},
        {"text": "Giờ Đến", "stretch": False, 'width': 60},
        {"text": "Biển Số", "stretch": False, 'width': 60},
        {"text": "Số Ghế", "stretch": False, 'width': 55},
        {"text": "Giá Vé", "stretch": False, 'width': 60},
        {"text": "Tiến Độ", "stretch": False, 'width': 80},
    ]

    table = Tableview(master=canvas2, coldata=coldata, rowdata=[], paginated=True, pagesize=16, autofit=False,
                      searchable=False, bootstyle=DARK, height=16)
    table.pack(fill=BOTH, expand=YES, padx=0, pady=0)
    table.load_table_data()

    thong_tin_user(table)

    def get_info_ctm():
        global USER_ID
        query = (f"SELECT HoTenKH, SoDienThoai, EMail FROM KhachHang "
                 f"WHERE MSKH = '{USER_ID}'")
        ck, debug, data = execute_querry(query)
        if len(data) > 0:
            return [str(e) for e in list(data[0])]
        else:
            show_dialog('Hệ thống lỗi, vui lòng đăng nhập lại')

    def huy_ve():
        row_selected = table.get_rows(selected=True)
        if len(row_selected) > 0:
            data = row_selected[0].values
            ma_dv = data[0]
            trang_thai = data[-1]
            if trang_thai == "Đã Đặt":
                if xac_nhan_huy_ve(ma_dv):
                    query3 = f"UPDATE DatVeXe SET TrangThai='Đã Hủy' WHERE MaDV = '{ma_dv}'"
                    _, _, _ = execute_querry(query3)
                    thong_tin_user(table)
            elif trang_thai == "Hoàn Thành":
                messagebox.askokcancel("Hủy Thất Bại", "Vé đã thanh toán rồi !")
            else:
                messagebox.askokcancel("Hủy Thất Bại", "Vé này đã hủy rồi !")

    def danh_gia():
        row_selected = table.get_rows(selected=True)
        if len(row_selected) > 0:
            data = row_selected[0].values
            ma_dv = data[0]
            show_review_dialog(window, ma_dv)

    def hoan_thanh():
        row_selected = table.get_rows(selected=True)
        ma_dv = None
        if len(row_selected) > 0:
            data = row_selected[0].values
            ma_dv = data[0]
        result = messagebox.askokcancel("Xác Nhận thanh Toán", "Xác Nhận Hoàn Thành Chuyến Đi ?")
        if result:
            query3 = f"UPDATE DatVeXe SET TrangThai='Hoàn Thành' WHERE MaDV = '{ma_dv}'"
            _, _, _ = execute_querry(query3)
            thong_tin_user(table)
            return True
        else:
            return False


    image_image_1 = PhotoImage(file=relative_to_assets("image_1.png", 4))
    image_1 = canvas.create_image(450.0, 270.0, image=image_image_1)
    image_image_2 = PhotoImage(file=relative_to_assets("image_2.png", 4))
    image_2 = canvas.create_image(450.0, 22.0, image=image_image_2)
    image_image_3 = PhotoImage(file=relative_to_assets("image_3.png", 4))
    image_3 = canvas.create_image(448.0, 222.0, image=image_image_3)
    image_image_4 = PhotoImage(file=relative_to_assets("image_4.png", 4))
    image_4 = canvas.create_image(449.0, 22.0, image=image_image_4)
    image_image_5 = PhotoImage(file=relative_to_assets("image_5.png", 4))
    image_5 = canvas.create_image(474.0, 421.0, image=image_image_5)
    image_image_6 = PhotoImage(file=relative_to_assets("image_6.png", 4))
    image_6 = canvas.create_image(124.0, 421.0, image=image_image_6)
    image_image_7 = PhotoImage(file=relative_to_assets("image_7.png", 4))
    image_7 = canvas.create_image(473.0, 462.0, image=image_image_7)
    image_image_8 = PhotoImage(file=relative_to_assets("image_8.png", 4))
    image_8 = canvas.create_image(135.0, 462.0, image=image_image_8)

    nv = get_info_ctm()
    canvas.create_text(30, 433, anchor="nw", text="Họ Tên", fill="#000000", font=("Times New Roman", 14 * -1))
    canvas.create_text(30, 455, anchor="nw", text="SĐT", fill="#000000", font=("Times New Roman", 14 * -1))
    canvas.create_text(120, 433, anchor="nw", text=nv[0], fill="#000000", font=("Times New Roman", 14 * -1))
    canvas.create_text(120, 455, anchor="nw", text=nv[1], fill="#000000", font=("Times New Roman", 14 * -1))

    bbt1 = BButton(bootstyle="info", text='Đổi Mật Khẩu', command=lambda: change_password_dialog(window))
    bbt1.place(x=25, y=480, w=200)



    bbt1 = BButton(bootstyle="dark", text='Làm Mới', command=lambda: thong_tin_user(table))
    bbt1.place(x=290, y=435, w=170)
    bbt1 = BButton(bootstyle="warning", text='Đánh Giá', command=lambda: danh_gia())
    bbt1.place(x=485, y=435, w=170)
    bbt1 = BButton(bootstyle="success", text='Hoàn Thành', command=lambda: hoan_thanh())
    bbt1.place(x=290, y=480, w=170)
    bbt1 = BButton(bootstyle="danger", text='Hủy Vé', command=lambda: huy_ve())
    bbt1.place(x=485, y=480, w=170)
    def stuff(x):
        if x == 'Đăng Nhập Tài Khoản Khác':
            show_login(window)
        elif x == 'Tìm Xe':
            show_find(window)
        elif x == 'Quản Lý Chuyến Xe (Login EMP)':
            show_loginc(window)
        else:
            pass

    my_menu = BMenubutton(bootstyle="dark-outline", text="Menu")
    my_menu.place(x=5, y=5)
    inside_menu = BMenu(my_menu)
    item_var = StringVar()
    for x in ['Đăng Nhập Tài Khoản Khác', 'Tìm Xe', 'Lịch Sử Chuyến Đi', 'Quản Lý Chuyến Xe (Login EMP)']:
        inside_menu.add_radiobutton(label=x, variable=item_var, command=lambda x=x: stuff(x))
    my_menu['menu'] = inside_menu

    window.resizable(False, False)
    window.mainloop()


def show_loginc(window):
    # Hàm xử lý sự kiện khi nhấn vào nút login
    def login(email, password):
        global EMP_ID
        if '@' not in email:
            show_dialog("Email không hợp lệ")
        else:
            # Truy vấn lấy mật khẩu và mã số khách hàng để kiểm tra xác thực
            query = f"SELECT MatKhau, MSNV FROM NHANVIEN WHERE EMail = '{email}'"
            ck, debug, data = execute_querry(query)
            if len(data) > 0:
                if list(data[0])[0] == password:
                    EMP_ID = list(data[0])[1]
                    show_emp(window)
                else:
                    show_dialog('Sai mật khẩu')
            else:
                show_dialog('Email chưa đăng ký')

    window.geometry("700x450")
    window.configure(bg="#FFFFFF")
    window.lift()
    canvas = Canvas(window, bg="#FFFFFF", height=450, width=700, bd=0, highlightthickness=0, relief="ridge")
    canvas.place(x=0, y=0)
    image_image_1 = PhotoImage(file=relative_to_assets("image_1.png", 5))
    image_1 = canvas.create_image(144.0, 225.0, image=image_image_1)
    image_image_2 = PhotoImage(file=relative_to_assets("image_2.png", 5))
    image_2 = canvas.create_image(481.0, 225.0, image=image_image_2)
    canvas.create_text(343.0, 132.0, anchor="nw", text="Email", fill="#000000", font=("Calibri Bold", 14 * -1))
    canvas.create_text(342.0, 208.0, anchor="nw", text="Password", fill="#000000", font=("Calibri Bold", 14 * -1))
    canvas.create_text(403.0, 38.0, anchor="nw", text="Login", fill="#000000", font=("Calibri Bold", 64 * -1))
    image_image_3 = PhotoImage(file=relative_to_assets("image_3.png", 5))
    image_3 = canvas.create_image (481.0, 173.0, image=image_image_3)
    image_image_4 = PhotoImage (file=relative_to_assets("image_4.png", 5))
    image_4 = canvas.create_image (480.0, 249.0, image=image_image_4)
    entry_image_1 = PhotoImage (file=relative_to_assets("entry_1.png", 5))
    entry_bg_1 = canvas.create_image (481.5, 173.0, image=entry_image_1)
    entry_1 = Entry (bd=0, bg="#FFFFFF", fg="#000716", highlightthickness=0)
    entry_1.place (x=350.0, y=162.0, width=263.0, height=20.0)
    entry_image_2 = PhotoImage (file=relative_to_assets("entry_2.png", 5))
    entry_bg_2 = canvas.create_image (481.5, 249.0, image=entry_image_2)
    entry_2 = Entry (bd=0, bg="#FFFFFF", fg="#000716", highlightthickness=0, show='*')
    entry_2.place (x=350.0, y=238.0, width=263.0, height=20.0)
    button_image_1 = PhotoImage (file=relative_to_assets("button_1.png", 5))
    button_1 = Button (image=button_image_1, borderwidth=0, highlightthickness=0, command=lambda: login(entry_1.get(), entry_2.get()), relief="flat")
    button_1.place (x=391.0, y=289.0, width=180.0, height=45.0)
    canvas.create_text(347.0, 378.0, anchor="nw", text="Log in as a customer ... ", fill="#000000",font=("Calibri Light", 14 * -1))
    button_image_3 = PhotoImage(file=relative_to_assets("button_3.png", 5))
    button_3 = Button(image=button_image_3, borderwidth=0, highlightthickness=0, command=lambda: show_login(window), relief="flat")
    button_3.place(x=514.0, y=378.0, width=99.0, height=17.0)
    window.resizable(False, False)
    window.mainloop()


def show_emp(window):
    window.geometry("900x540")
    window.configure(bg="#FFFFFF")
    window.lift()
    def get_info_emp():
        global EMP_ID
        #query = f"SELECT HoTenNV, SoDienThoai, ChucVu, MSNX, EMail FROM NHANVIEN WHERE MSNV = '{EMP_ID}'"
        query = (f"SELECT A.HoTenNV, A.SoDienThoai, A.ChucVu, B.TenNX, A.EMail, A.MSNX FROM NhanVien A, NhaXe B "
                 f"WHERE A.MSNV = '{EMP_ID}' AND A.MSNX = B.MSNX")
        ck, debug, data = execute_querry(query)
        if len(data) > 0:
            return [str(e) for e in list(data[0])]
        else:
            show_dialog('Hệ thống lỗi, vui lòng đăng nhập lại')

    def hien_thi_tat_ca(ngay_dv):
        global QUERY
        ngay_dv = chuyen_ngay(ngay_dv)
        QUERY = (f"SELECT A.MaCX, E.TenNX, CONCAT(CONCAT(CONCAT(D.TenLoai, ' '), D.SoTang), ' Tầng'), "
                 f"B.DiemBatDau, B.DiemKetThuc, A.GioKhoiHanh, A.GioCapBen, C.BienSo, "
                 f"CONCAT(CONCAT(CAST(COALESCE("
                 f"(SELECT COUNT(*) FROM DatVeXe G, VeXe H "
                 f"WHERE A.MaCX = H.MaCX "
                 f"AND G.MaVX = H.MaVX "
                 f"AND H.NgayXeChay = '{ngay_dv}' "
                 f"AND G.TrangThai = 'Đã Đặt'), "
                 f"'0') AS VARCHAR(4)), '/'), A.SoGheTrong), "
                 f"(SELECT F.HoTenNV FROM NhanVien F WHERE A.MSNV1 = F.MSNV), "
                 f"(SELECT F.HoTenNV FROM NhanVien F WHERE A.MSNV2 = F.MSNV), "
                 f"COALESCE((SELECT COUNT(*) FROM DanhGia F, VeXe G WHERE A.MaCX = G.MaCX AND F.MaVX = G.MaVX), 'Chưa có') AS SoLuotDanhGia "
                 f"FROM ChuyenXe A, TuyenDuong B, Xe C, LoaiXe D, NhaXe E "
                 f"WHERE A.MaTD = B.MaTD AND	A.MaXe = C.MaXe AND C.MaLoai = D.MaLoai AND C.MSNX = E.MSNX ")
        update_find_table(table, nv=True)

    def xem_thong_tin_kh(ngay_dv):
        ngay_dv = chuyen_ngay(ngay_dv)
        row_selected = table.get_rows(selected=True)
        if len(row_selected) > 0:
            table_dialog = Toplevel(window)
            table_dialog.title("Thông Tin Chuyến Xe")
            table_dialog.transient(window)
            table_dialog.resizable(False, False)

            coldata = [{"text": "Ghế", "stretch": False, 'width': 70},
                       {"text": "Họ Tên", "stretch": False, 'width': 150},
                       {"text": "SDT", "stretch": False, 'width': 70},
                       {"text": "Email", "stretch": False, 'width': 150}]

            table2 = Tableview(master=table_dialog, coldata=coldata, rowdata=[], paginated=True, pagesize=16, autofit=False,
                               searchable=True, bootstyle=INFO, height=16)
            table2.pack(fill=BOTH, expand=YES, padx=0, pady=0)
            table2.load_table_data()

            MaCX = list(row_selected[0].values)[0]

            # Thực hiện truy vấn để lấy các dữ liệu cho dòng tài xế và phụ xế

            query = (f"SELECT B.HoTenNV, B.SoDienThoai, B.EMail, C.HoTenNV, C.SoDienThoai, C.EMail "
                     f"FROM ChuyenXe A, NhanVien B, NhanVien C  "
                     f"WHERE A.MaCX = '{MaCX}' AND A.MSNV1 = B.MSNV AND A.MSNV2 = C.MSNV")
            _, _, data = execute_querry(query)
            data = list(data[0])
            data[0] += ' (Tài Xế)'
            data[3] += ' (Phụ Xế)'
            table2.insert_row('end', ['0'] + data[:3])
            table2.insert_row('end', ['0'] + data[3:])
            table2.load_table_data()


            # Thực hiện truy vấn để lấy các dữ liệu cho khách hàng
            query = (f"SELECT G.SoGhe, A.HoTenKH, A.SoDienThoai, A.EMail "
                     f"FROM KhachHang A, DatVeXe B, VeXe G "
                     f"WHERE G.MaCX = '{MaCX}' AND A.MSKH = B.MSKH "
                     f"AND B.MaVX = G.MaVX "
                     f"AND G.NgayXeChay = '{ngay_dv}' AND B.TrangThai <> 'Đã Hủy'")
            _, _, data = execute_querry(query)
            for d in data:
                row = list(d)
                table2.insert_row('end', row)
                table2.load_table_data()

            def ok_button_callback():
                table_dialog.destroy()

            ok_button = BButton(table_dialog, bootstyle="info", text="OK", command=ok_button_callback)
            ok_button.pack(pady=10)
            show_center(table_dialog)
        else:
            show_dialog("Vui lòng chọn chuyến xe để xem")

    # Hàm xử lý sự kiện khi nhấn vào nút xem bình luận
    def xem_binh_luan():
        # Tạo cửa sổ dialog
        row_selected = table.get_rows(selected=True)
        if len(row_selected) > 0:
            table_dialog = Toplevel(window)
            table_dialog.title("Đánh giá và Bình luận")
            table_dialog.transient(window)
            table_dialog.resizable(False, False)
            show_center(table_dialog)

            coldata = [{"text": "Tên", "stretch": False, 'width': 100},
                       {"text": "Ngày Xe Chạy", "stretch": False, 'width': 100},
                       {"text": "Bình Luận", "stretch": False, 'width': 250},
                       {"text": "Đánh Giá", "stretch": False, 'width': 70}]

            table2 = Tableview(master=table_dialog, coldata=coldata, rowdata=[], paginated=True, pagesize=10, autofit=False,
                               searchable=True, bootstyle=PRIMARY, height=10)
            table2.pack(fill=BOTH, expand=YES, padx=0, pady=0)
            table2.load_table_data()

            MaCX = list(row_selected[0].values)[0]
            # Thực hiện truy vấn để lấy các dữ liệu cho bảng bình luận
            query = (f"SELECT A.HoTenKH, G.NgayXeChay, B.MoTa, B.SoDiem "
                     f"FROM KhachHang A, DanhGia B, VeXe G "
                     f"WHERE G.MaCX = '{MaCX}' AND A.MSKH = B.MSKH AND B.MaVX = G.MaVX")
            _, _, data = execute_querry(query)
            tong_dg, luot_dg = 0, 0
            for d in data:
                row = list(d)
                if row[2] == '':
                    row[2] = 'Không bình luận'
                row[1] = row[1].strftime("%d-%m-%Y")
                tong_dg, luot_dg = tong_dg + int(row[3]), luot_dg + 1
                table2.insert_row('end', row)
                table2.load_table_data()

            def ok_button_callback():
                table_dialog.destroy()
            try:
                dg_tb = str(round(tong_dg/luot_dg, 2))
            except ZeroDivisionError:
                dg_tb = "Chưa có đánh giá"

            label1 = BLabel(table_dialog, bootstyle="danger", text="Điểm Đánh Giá Trung Bình : " + dg_tb, font=("Helvetica", 9))
            label2 = BLabel(table_dialog, bootstyle="danger", text="Tổng Số Lượt Đánh Giá : " + str(luot_dg), font=("Helvetica", 9))
            frame = Frame(table_dialog)
            label1.pack(pady=5)
            label2.pack(pady=5)
            ok_button = BButton(table_dialog, bootstyle="primary", text="OK", command=ok_button_callback)
            ok_button.pack(pady=10)
            frame.pack()
        else:
            show_dialog("Vui lòng chọn chuyến xe để xem")

    def xem_doanh_thu(nam):
        table_dialog = Toplevel(window)
        table_dialog.title("Doanh Thu")
        table_dialog.transient(window)
        table_dialog.resizable(False, False)
        show_center(table_dialog)
        my_notebook = BNotebook(table_dialog, bootstyle="warning")
        my_notebook.pack(pady=0)
        tablist = []
        nv = get_info_emp()
        msnx = nv[5]
        doanh_thu_nam = 0
        for i in range(12):
            tablist.append(BFrame(my_notebook))
            tab = tablist[i]
            text = "Doanh thu tháng " + str(i+1) + " của nhà xe " + nv[3] + " trong năm " + str(nam)
            new_label = BLabel(tab, text=text, font=("Helvetica", 15), bootstyle="danger")
            new_label.pack(pady=5)

            coldata = [{"text": "Mã CX", "stretch": False, 'width': 60},
                       {"text": "Loại Xe", "stretch": False, 'width': 170},
                       {"text": "Xuất Phát", "stretch": False, 'width': 80},
                       {"text": "Điểm Đến", "stretch": False, 'width': 80},
                       {"text": "Biển Số", "stretch": False, 'width': 70},
                       {"text": "Giờ Đi", "stretch": False, 'width': 70},
                       {"text": "Giờ Đến", "stretch": False, 'width': 70},
                       {"text": "Doanh Thu", "stretch": False, 'width': 110}]

            table2 = Tableview(master=tab, coldata=coldata, bootstyle=DANGER, height=8, pagesize=8, rowdata=[], autofit=False, searchable=True, paginated=True)
            table2.pack(fill=BOTH, expand=YES, padx=0, pady=0)
            table2.load_table_data()
            doanh_thu_thang = 0

            # Truy vấn tìm tất cả các chuyến xe của nhà xe

            query = (f"SELECT D.MaCX, B.SoGhe, B.SoTang, B.TenLoai, C.BienSo, "
                     f"E.DiemBatDau, E.DiemKetThuc, D.GioKhoiHanh, D.GioCapBen "
                     f"FROM NhaXe A, LoaiXe B, Xe C, ChuyenXe D, TuyenDuong E "
                     f"WHERE A.MSNX = '{msnx}' AND A.MSNX = C.MSNX AND B.MaLoai = C.MaLoai "
                     f"AND C.MaXe = D.MaXe AND D.MaTD = E.MaTD")
            _, _, data = execute_querry(query)
            table_data = []
            for d in data:
                row = list(d)
                doanh_thu_chuyen_xe = 0


                # Truy vấn tìm tất cả các vé đã hoàn thành thanh toán trong tháng theo từng mã chuyến xe

                query = (f"SELECT B.MaCX, B.GiaVe, MONTH(B.NgayXeChay) FROM DatVeXe A, VeXe B, ChuyenXe D "
                         f"WHERE B.MaCX = '{row[0]}' AND B.MaCX = D.MaCX AND A.MaVX = B.MaVX AND A.TrangThai = 'Hoàn Thành' "
                         f"AND YEAR(B.NgayXeChay) = '{nam}' AND MONTH(B.NgayXeChay) = '{i+1}'")

                _, _, data2 = execute_querry(query)
                for j in data2:
                    row2 = list(j)
                    doanh_thu_chuyen_xe += row2[1]

                table_data.append([row[0], row[3] + " " + str(row[2]) + " Tầng", row[5], row[6], row[4],
                                   datetime_to_string(row[7]), datetime_to_string(row[8]), doanh_thu_chuyen_xe])

                doanh_thu_thang += doanh_thu_chuyen_xe

            for row in table_data:
                table2.insert_row('end', row)
                table2.load_table_data()
            tdt = BLabel(tab, text="Tổng Doanh Thu Tháng " + str(i+1) + " là: " + str(doanh_thu_thang), font=("Helvetica Bold", 11), bootstyle="dark")
            tdt.pack(pady=0, side=RIGHT)
            my_notebook.add(tab, text="Tháng " + str(i+1))

            doanh_thu_nam += doanh_thu_thang

        def ok_button_callback():
            table_dialog.destroy()

        label1 = BLabel(table_dialog, bootstyle="success", text="Tổng Doanh Thu Năm là: " + str(doanh_thu_nam), font=("Helvetica", 11))
        frame = Frame(table_dialog)
        label1.pack(pady=0)
        ok_button = BButton(table_dialog, bootstyle="danger", text="OK", command=ok_button_callback)
        ok_button.pack(pady=5)
        frame.pack()


    canvas = Canvas(window, bg="#FFFFFF", height=540, width=900, bd=0, highlightthickness=0, relief="ridge")
    canvas.place(x=0, y=0)
    image_image_1 = PhotoImage(file=relative_to_assets("image_1.png", 6))
    image_1 = canvas.create_image(450.0, 270.0, image=image_image_1)
    image_image_2 = PhotoImage(file=relative_to_assets("image_2.png", 6))
    image_2 = canvas.create_image(450.0, 22.0, image=image_image_2)
    image_image_3 = PhotoImage(file=relative_to_assets("image_3.png", 6))
    image_3 = canvas.create_image(122.0, 441.0, image=image_image_3)
    image_image_4 = PhotoImage(file=relative_to_assets("image_4.png", 6))
    image_4 = canvas.create_image(488.0, 441.0, image=image_image_4)
    image_image_5 = PhotoImage(file=relative_to_assets("image_5.png", 6))
    image_5 = canvas.create_image(448.0, 198.0, image=image_image_5)
    image_image_6 = PhotoImage(file=relative_to_assets("image_6.png", 6))
    image_6 = canvas.create_image(451.0, 22.0, image=image_image_6)
    image_image_7 = PhotoImage(file=relative_to_assets("image_7.png", 6))
    image_7 = canvas.create_image(122.0, 377.0, image=image_image_7)
    image_image_8 = PhotoImage(file=relative_to_assets("image_8.png", 6))
    image_8 = canvas.create_image(488.0, 377.0, image=image_image_8)

    nv = get_info_emp()
    canvas.create_text(25, 395, anchor="nw", text="Họ Tên", fill="#000000",font=("Times New Roman", 14 * -1))
    canvas.create_text(25, 420, anchor="nw", text="Nhà Xe", fill="#000000", font=("Times New Roman", 14 * -1))
    canvas.create_text(25, 445, anchor="nw", text="Chức Vụ", fill="#000000", font=("Times New Roman", 14 * -1))
    canvas.create_text(25, 470, anchor="nw", text="SĐT", fill="#000000", font=("Times New Roman", 14 * -1))
    canvas.create_text(25, 495, anchor="nw", text="EMail", fill="#000000", font=("Times New Roman", 14 * -1))
    canvas.create_text(100, 395, anchor="nw", text=nv[0], fill="#000000", font=("Times New Roman", 14 * -1))
    canvas.create_text(100, 420, anchor="nw", text=nv[3], fill="#000000", font=("Times New Roman", 14 * -1))
    canvas.create_text(100, 445, anchor="nw", text=nv[2], fill="#000000", font=("Times New Roman", 14 * -1))
    canvas.create_text(100, 470, anchor="nw", text=nv[1], fill="#000000", font=("Times New Roman", 14 * -1))
    canvas.create_text(100, 495, anchor="nw", text=nv[4], fill="#000000", font=("Times New Roman", 14 * -1))
    canvas2 = Canvas(window, width=890, height=700)
    canvas2.place(x=20, y=65)
    coldata = [
        {"text": "Mã CX", "stretch": False, 'width': 30},
        {"text": "Nhà Xe", "stretch": False, 'width': 90},
        {"text": "Loại Xe", "stretch": False, 'width': 170},
        {"text": "Xuất Phát", "stretch": False, 'width': 70},
        {"text": "Điểm Đến", "stretch": False, 'width': 70},
        {"text": "Giờ Đi", "stretch": False, 'width': 60},
        {"text": "Giờ Đến", "stretch": False, 'width': 60},
        {"text": "Biển Số", "stretch": False, 'width': 55},
        {"text": "Ghế", "stretch": False, 'width': 45},
        {"text": "Tài Xế", "stretch": False, 'width': 100},
        {"text": "Phụ Xế", "stretch": False, 'width': 100},
    ]
    table = Tableview(master=canvas2, coldata=coldata, rowdata=[], paginated=True, pagesize=12, autofit=False,
                      searchable=False, bootstyle=INFO, height=12)
    table.pack(fill=BOTH, expand=YES, padx=0, pady=0)
    table.load_table_data()
    cal = DateEntry(bootstyle="info", dateformat=r"%d-%m-%Y")
    cal.place(x=500, y=390, w=200)
    bbt1 = BButton(bootstyle="info-outline", text='Xem Chuyến Xe Trong Ngày', command=lambda: hien_thi_tat_ca(cal.entry.get()))
    bbt1.place(x=270, y=390, w=200)
    bbt2 = BButton(bootstyle="primary-outline", text='Xem Thông Tin Chuyến Xe', command=lambda: xem_thong_tin_kh(cal.entry.get()))
    bbt2.place(x=270, y=480, w=200)
    bbt3 = BButton(bootstyle="primary-outline", text='Xem Đánh Giá Khách Hàng', command=lambda: xem_binh_luan())
    bbt3.place(x=500, y=480, w=200)
    bbt2 = BButton(bootstyle="danger-outline", text='Xem Doanh Thu Trong Năm', command=lambda: xem_doanh_thu(bbt4.get()))
    bbt2.place(x=270, y=435, w=200)
    bbt4 = BSpinbox(bootstyle="danger", from_=1990, to=3000)
    nam_hien_tai = datetime.now().date()
    nam_hien_tai = nam_hien_tai.strftime("%Y-%m-%d")
    nam_hien_tai = nam_hien_tai.split("-")[0]
    bbt4.set(int(nam_hien_tai))
    bbt4.place(x=500, y=435, w=200)

    def stuff(x):
        if x == 'Đăng Nhập Tài Khoản Nhân Viên Khác':
            show_loginc(window)
        elif x == 'Đăng Nhập Tài Khoản Khách Hàng':
            show_login(window)
        else:
            pass
    my_menu = BMenubutton(bootstyle="dark-outline", text="Menu")
    my_menu.place(x=5, y=5)
    inside_menu = BMenu(my_menu)
    item_var = StringVar()
    for x in ['Đăng Nhập Tài Khoản Nhân Viên Khác', 'Đăng Nhập Tài Khoản Khách Hàng', 'Quản Lý Chuyến Xe']:
        inside_menu.add_radiobutton(label=x, variable=item_var, command=lambda x=x: stuff(x))
    my_menu['menu'] = inside_menu

    window.resizable(False, False)
    window.mainloop()


show_login(window)









